/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <limits>

struct Student {
    std::string name;
    double grade;
};

int main() {
    std::vector<Student> students;
    std::string name;
    double grade;
    char more;

    std::cout << "Grade system of student " << std::endl;

    // Taking input from user
    do {
        std::cout << "Enter student name: ";
        std::cin >> name;
        std::cout << "Enter grade for " << name << ": ";
        std::cin >> grade;

        // Adding student to the list
        students.push_back({name, grade});

        std::cout << "Do you want to add another student? (y/n): ";
        std::cin >> more;
    } while (more == 'y' || more == 'Y');

    // Calculation of grades as average, highest, and lowest grades
    double sum = 0.0;
    double highest = std::numeric_limits<double>::min();
    double lowest = std::numeric_limits<double>::max();

    for (const auto& student : students) {
        sum += student.grade;
        if (student.grade > highest) {
            highest = student.grade;
        }
        if (student.grade < lowest) {
            lowest = student.grade;
        }
    }

    double average = sum / students.size();

    // Result is display
    std::cout << "\nSummary:\n";
    std::cout << "Number of students: " << students.size() << std::endl;
    std::cout << "Average grade: " << average << std::endl;
    std::cout << "Highest grade: " << highest << std::endl;
    std::cout << "Lowest grade: " << lowest << std::endl;

    return 0;
}
